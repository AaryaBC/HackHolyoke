//
//  ViewController.swift
//  CampusSafety
//
//  Created by Aarya BC on 11/11/17.
//  Copyright © 2017 Aarya BC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

