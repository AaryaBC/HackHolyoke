//
//  HomeViewController.swift
//  CampusSafety
//
//  Created by Aarya BC on 11/11/17.
//  Copyright © 2017 Aarya BC. All rights reserved.
//

import UIKit
import Parse
import CoreLocation

class HomeViewController: UIViewController, CLLocationManagerDelegate{
    
    let locationManager = CLLocationManager()
    
    
    @IBOutlet weak var trackMeButton: UIButton!
    var tracking = true
    var safety = true
    
    @IBAction func getLocation(_ sender: Any) {
        if (tracking){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
            self.tracking = false
            self.trackMeButton.setTitle("I'm Safe", for: .normal)
        }
        else{
            self.trackMeButton.setTitle("Track Me", for: .normal)
            locationManager.stopUpdatingLocation()
        }
    }
    
    @IBAction func getHelp(_ sender: Any) {
        self.safety = false
    }
    
    //get location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil) {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                let pm = placemarks?[0]
                let post = PFObject(className: "Location")
                post["latitude"] = pm!.location!.coordinate.latitude
                post["longitude"] = pm!.location!.coordinate.latitude
                post["safe"] = self.safety
                print("work")
                post.saveInBackground()
                
            } else {
                print("Problem with the data received from geocoder")
            }
        })
    }
    
    //
    
    
    //error for location
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error while updating location " + error.localizedDescription)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
